

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AmtTransfer1
 */
public class AmtTransfer1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AmtTransfer1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		Connection con =DBConnection.connect();
		int Acc1=Data.getAcc_Num(),Acc2;
		Acc1=Integer.parseInt(request.getParameter("RAcc_Num1"));
		Acc2=Integer.parseInt(request.getParameter("RAcc_Num2"));
		int TAmt=Integer.parseInt(request.getParameter("Transfer"));
		if (TAmt>0){
		
		try {
			String sql1 = "select Balance from user where Acc_Num = ?";
		
			PreparedStatement pst1;
			pst1 = con.prepareStatement(sql1);
			pst1.setInt(1, Acc1);
			
			ResultSet rs = pst1.executeQuery();
			
			int OldBal1=0;
			if(rs.next()){
				OldBal1 = rs.getInt("Balance");
			
	//	
			String sql3 = "select balance from user where Acc_Num = ?";
			
			PreparedStatement pst3;
			pst3 = con.prepareStatement(sql3);
			pst3.setInt(1, Acc2);
			
			ResultSet rs1 = pst3.executeQuery();
			
			int Oldbal2=0;
			if(rs1.next()){
				Oldbal2 = rs1.getInt("Balance");
				}
			else{
				response.sendRedirect("404.html");
				}
			if(OldBal1>=TAmt)
			{
			int Bal1 =OldBal1-TAmt;
			String sql2 ="update user set Balance = ? where Acc_Num=?";
			PreparedStatement pst2 = con.prepareStatement(sql2);
			pst2.setInt(1,Bal1 );
			pst2.setInt(2,Acc1);
			pst2.executeUpdate();
			}
			else{
				response.sendRedirect("404.html");
				}
			
			int Bal2 =Oldbal2+TAmt;
			String sql4 ="update user set Balance = ? where Acc_Num=?";
			PreparedStatement pst4 = con.prepareStatement(sql4);
			pst4.setInt(1,Bal2 );
			pst4.setInt(2,Acc2);
			int i=pst4.executeUpdate();
			if(i>0){
				response.sendRedirect("create.html");
				}
			}
		}catch(Exception e)
			{
			e.printStackTrace();
			}
	}
		else{
			response.sendRedirect("404.html");
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

public class Data {
	static int Acc_Num;
	static String Email;

	public static String getEmail() {
		return Email;
	}

	public static void setEmail(String email) {
		Email = email;
	}

	public static int getAcc_Num() {
		return Acc_Num;
	}

	public static void setAcc_Num(int acc_Num) {
		Acc_Num = acc_Num;
	}

}

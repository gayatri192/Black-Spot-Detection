

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Amtwithdraw
 */
public class Amtwithdraw extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Amtwithdraw() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		Connection con = DBConnection.connect();

		int Acc_Num=Data.getAcc_Num();
		int Bal=0;
		
	    Acc_Num = Integer.parseInt(request.getParameter("Acc_Num"));
		int Withdraw=Integer.parseInt(request.getParameter("Withdrawl"));
		if(Withdraw>0)
		{
			try {
				
				String sql1 = "select Balance from user where Acc_Num = ?";
			
				PreparedStatement pst;
				pst = con.prepareStatement(sql1);
				pst.setInt(1, Acc_Num);
				
				ResultSet rs = pst.executeQuery();
				
				int Oldbal=0;
				if(rs.next())
				{
					Oldbal = rs.getInt("balance");
				}
				if(Oldbal>=Withdraw)
				{
					Bal = Oldbal-Withdraw;
					String sql2 ="update user set Balance=? where Acc_Num=?";
					PreparedStatement pst2 = con.prepareStatement(sql2);
					pst2.setInt(1,Bal );
					pst2.setInt(2,Acc_Num);
					int s=pst2.executeUpdate();
					if(s>0)
					{
						response.sendRedirect("create.html");
					}
					else
					{
						response.sendRedirect("withdraw.html");
					}
				}
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				}	
		}
		else{
			response.sendRedirect("404.html");
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

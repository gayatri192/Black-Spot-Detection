

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AccountCreation
 */
public class AccountCreation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AccountCreation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
    	int Acc_Num=0;
    	String Name,Email,Mob_Num,PWS,City;
    	
    	Name=request.getParameter("Name");
    	Email=request.getParameter("Email");
    	Mob_Num=request.getParameter("Mob_Num");
    	PWS=request.getParameter("PWS");
    	int Balance=Integer.parseInt(request.getParameter("Balance"));
    	City=request.getParameter("City");
    	System.out.println("yukta");
    	try 
    	{
    	
    		Connection con = DBConnection.connect();
            String sql = "insert into user values(?,?,?,?,?,?,?)"; 
       
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setInt(1, Acc_Num);
			pst.setString(2, Name);
			pst.setString(3, Email);
			pst.setString(4, Mob_Num);
			pst.setString(5, PWS);
			pst.setInt(6, Balance);
			pst.setString(7, City);
			int i=pst.executeUpdate();
			
			if(i>0){
				//System.out.println("Hii");
				response.sendRedirect("login.html");
			}
			else{
				response.sendRedirect("registration.html");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
